<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=Edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <!-- SITE TITLE -->
    <title>Second Page</title>

    <!-- STYLESHEETS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/templatemo-style.css" />
    <link
      href="//fonts.googleapis.com/css?family=Raleway:400,300,600,700"
      rel="stylesheet"
      type="text/css"
    />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  </head>
  <body data-spy="scroll" data-target="#rock-navigation">
    <!-- START HOME -->
    <section id="home" class="templatemo-home">
      <div class="container">
        <div class="row">
          <div class="col-md-2 col-sm-1"></div>
          <div class="col-md-8 col-sm-10">
            <a
              href="#work"
              class="btn btn-default smoothScroll tm-view-more-btn"
              >Let's Begin</a
            >
          </div>
          <div class="col-md-2 col-sm-1"></div>
        </div>
      </div>
    </section>
    <!-- END HOME -->

    <!-- START work -->
    <section id="work" class="tm-padding-top-bottom-100">
      <div class="container">
        <div class="row">
          <div class="col-md-offset-1 col-md-11">
            <h2 class="title"><strong>Metrics</strong></h2>
          </div>
          <div class="col-md-4 col-sm-4">
            <div class="work-wrapper">
              <!-- <i class="fa fa-link"></i> -->
              <h3 class="text-uppercase tm-work-h3"> Average People </h3>
              <hr />
              <p> average number of people per frame (includes both violators and non-violators)
                <h3 id="avgppl"> 10</h3>
            </div>
          </div>
          <div class="col-md-4 col-sm-4">
            <div class="work-wrapper">
              <!-- <i class="fa fa-flash"></i> -->
              <h3 class="text-uppercase tm-work-h3">Average Number of clusters</h3>
              <hr />
              <p>
                Average number of clusters per frame 
              </p>
              <h3 id = "avgclusters"> 10</h3>
            </div>
          </div>
          <div class="col-md-4 col-sm-4">
            <div class="work-wrapper">
              <!-- <i class="fa fa-dashboard"></i> -->
              <h3 class="text-uppercase tm-work-h3"> Average Number of Violators</h3>
              <hr />
              <p>
                Average number of people violating per frame     
              </p>
            <h3 id = "avgviolators"> 10</h3>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 col-sm-4">
            <!-- Add 2 buttons -->
            
            <div id="my_dataviz"></div>
          </div>
        </div>
      </div>
    </section>
    <!-- END work -->
    
      
      </script>


      <script type="text/javascript">
  var i = 0;
  (function worker() {
    console.log('hi')
  $.get('ajaxtext.txt', function(data) {
    console.log(data);
    if (data.length != 0) {
        data = data.split(' ')
        console.log(data)
        $('#avgppl').text(data[0]);
        $('#avgclusters').text(data[1]);
        $('#avgviolators').text(data[2]);
    }
    
    setTimeout(worker, 2000);
  });
})();
</script>
  </body>
</html>
